# Ear Clean: setup notes
## Hero video prompt (Runway / Pika / Sora)
Stylised 3D animation, 8 seconds, seamless loop, 16:9, 1920x1080, 24fps. Dark green (#1B4332) background with teal (#52796F) and gold (#C5A059) accents, soft studio lighting, calm medical feel. Cross-section of a translucent ear canal tunnel. 0-2s: the canal is blocked by small gold-toned bricks. 2-4s: a powerful jet of clear water sprays in from the left and blasts the bricks apart, bricks tumble out of frame. 4-6s: the canal opens and warm golden light flows through. 6-8s: glowing gold sound waves ripple through the open canal and fade, matching the first frame for a loop. Smooth camera push-in, no text, no logos, no people, no gore.
## Images needed (assets/img/)
1. hero-poster.jpg (1920x1080, first frame of the video, under 200KB; a tiny green placeholder is included)
2. og-image.jpg (1200x630 social share image)
3. audiologist-portrait.jpg (for about.html)
4. apple-touch-icon.png 180x180
5. Client photos for testimonials (optional, with permission)
6. Zoom, Teams, WhatsApp, Phone icons (official brand assets)
7. about-hero.jpg (optional page banner)
8. HPCSA / professional body logo (if permitted)
9. Payment method logos (if you add online payment)
10. Compressed .webp versions of all photos
